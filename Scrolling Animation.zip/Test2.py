
import os
import tkinter as tk
from typing import List
from PIL import Image, ImageTk


class SmoothReversePipeline:


    def __init__(
        self,
        root: tk.Tk,
        image_paths: List[str],
        window_count: int = 5,
        width: int = 400,
        height: int = 300,
        speed: int = 3,
        fps_delay: int = 16,
    ) -> None:
        self.root = root
        self.image_paths = image_paths
        self.window_count = window_count
        self.width = width
        self.height = height
        self.speed = speed
        self.fps_delay = fps_delay

        self.total_width = self.window_count * self.width

        self.canvases: List[tk.Canvas] = []
        self._create_windows()

        self.images = self._load_images()
        self.image_width = 200
        self.image_height = 200

        self.active_images = []  
        self.next_image_index = 0

        self._spawn_image(initial=True)
        self._animate()

    def _create_windows(self) -> None:
        
        for i in range(self.window_count):
            window = self.root if i == 0 else tk.Toplevel(self.root)
            window.title(f"Window {i + 1}")
            window.geometry(f"{self.width}x{self.height}+{100 + i * 420}+200")

            canvas = tk.Canvas(window, width=self.width, height=self.height)
            canvas.pack()

            self.canvases.append(canvas)

    def _load_images(self) -> List[ImageTk.PhotoImage]:
        
        loaded = []
        for path in self.image_paths:
            if not os.path.exists(path):
                raise FileNotFoundError(f"Missing image: {path}")

            img = Image.open(path)
            img = img.resize((200, 200), Image.Resampling.LANCZOS)
            loaded.append(ImageTk.PhotoImage(img, master=self.root))

        return loaded

    def _spawn_image(self, initial: bool = False) -> None:
        
        x_position = self.total_width if not initial else self.total_width - self.image_width
        self.active_images.append({
            "image": self.images[self.next_image_index],
            "x": x_position,
        })
        self.next_image_index = (self.next_image_index + 1) % len(self.images)

    def _animate(self) -> None:

        for obj in self.active_images:
            obj["x"] -= self.speed

   
        self.active_images = [
            obj for obj in self.active_images
            if obj["x"] > -self.image_width
        ]

   
        if (
            not self.active_images or
            self.total_width - self.active_images[-1]["x"] >= self.width
        ):
            self._spawn_image()

        self._render()
        self.root.after(self.fps_delay, self._animate)

    def _render(self) -> None:

        for canvas in self.canvases:
            canvas.delete("all")

        for obj in self.active_images:
            global_x = obj["x"]

            for i, canvas in enumerate(self.canvases):
                window_start = i * self.width
                window_end = window_start + self.width

                if window_start - self.image_width < global_x < window_end:
                    local_x = global_x - window_start
                    canvas.create_image(
                        local_x,
                        self.height // 2,
                        image=obj["image"],
                        anchor="w",
                    )


def main() -> None:
    root = tk.Tk()
    image_files = [f"{i}.png" for i in range(1, 12)]

    SmoothReversePipeline(root, image_files)
    root.mainloop()


if __name__ == "__main__":
    main()