# gestures.py
import time
import math

def detect_pinch(index_finger, thumb, threshold=0.08):
    return math.hypot(index_finger.x - thumb.x,
                       index_finger.y - thumb.y) < threshold

def get_zone(x, width):
    if x < width * 0.33:
        return "LEFT"
    elif x > width * 0.66:
        return "RIGHT"
    else:
        return "CENTER"

def should_trigger(zone, new_zone, zone_start, last_action, hold, cooldown):
    now = time.time()
    if new_zone != zone:
        return False, new_zone, now

    if new_zone != "CENTER":
        if (now - zone_start > hold) and (now - last_action > cooldown):
            return True, new_zone, now

    return False, zone, zone_start