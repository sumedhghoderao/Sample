# main.py
import cv2
import time
import mediapipe as mp
from gestures import detect_pinch, get_zone, should_trigger
from ui import draw_power_screen, draw_slider

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(
    max_num_hands=1,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.7
)

cap = cv2.VideoCapture(0)

images = [
    cv2.imread("assets/images/img1.jpg"),
    cv2.imread("assets/images/img2.jpg"),
    cv2.imread("assets/images/img3.jpg"),
    cv2.imread("assets/images/img4.jpg"),
    cv2.imread("assets/images/img5.jpg"),
]

img_index = 0
power_on = False
zone = "CENTER"
zone_start = time.time()
last_action = 0

while True:
    ret, frame = cap.read()
    frame = cv2.flip(frame, 1)
    h, w, _ = frame.shape

    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = hands.process(rgb)

    blink_left = blink_right = False

    if result.multi_hand_landmarks:
        hand = result.multi_hand_landmarks[0]
        idx = hand.landmark[8]
        thumb = hand.landmark[4]

        x = int(idx.x * w)
        y = int(idx.y * h)

        cv2.circle(frame, (x,y), 10, (0,255,0), -1)
        pinch = detect_pinch(idx, thumb)

        if not power_on:
            hover = abs(x - w//2) < 130 and abs(y - h//2) < 130
            draw_power_screen(frame, power_on, hover)
            if hover and pinch:
                power_on = True
                time.sleep(0.4)
            cv2.imshow("Gesture Demo", frame)
            if cv2.waitKey(1) == 27: break
            continue

        new_zone = get_zone(x, w)
        trigger, zone, zone_start = should_trigger(
            zone, new_zone, zone_start, last_action, 0.3, 0.6)

        if trigger:
            if new_zone == "LEFT":
                img_index = (img_index-1) % len(images)
                blink_left = True
            else:
                img_index = (img_index+1) % len(images)
                blink_right = True
            last_action = time.time()

    draw_slider(frame, images[img_index], blink_left, blink_right)
    cv2.imshow("Gesture Demo", frame)

    if cv2.waitKey(1) == 27:
        break

cap.release()
cv2.destroyAllWindows()
