# ui.py
import cv2

def draw_power_screen(frame, power_on, hover):
    h, w, _ = frame.shape
    center = (w//2, h//2)
    radius = 130

    color = (0,255,0) if power_on else (0,0,255)
    cv2.circle(frame, center, radius, color, -1)

    if hover:
        cv2.circle(frame, center, radius+10, (0,255,255), 5)

    text = "ON" if power_on else "OFF"
    cv2.putText(frame, text, (center[0]-40,center[1]+15),
                cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255,255,255), 3)

def draw_slider(frame, image, blink_left=False, blink_right=False):
    h, w, _ = frame.shape
    frame[:,:,:] = image

    if blink_left:
        cv2.putText(frame, "<", (50,h//2),
                    cv2.FONT_HERSHEY_SIMPLEX, 3, (255,255,255), 5)
    if blink_right:
        cv2.putText(frame, ">", (w-100,h//2),
                    cv2.FONT_HERSHEY_SIMPLEX, 3, (255,255,255), 5)
